var __bootStrapPath = "/Users/qrac/creative/suda-puppet/suda-puppet-project/Ch Data/temp.noindex/compiler/bootstrap.js";
var __compiledScene = "/Users/qrac/creative/suda-puppet/suda-puppet-project/Ch Data/temp.noindex/compiler/scene.json";
runScript("/Applications/Adobe Character Animator CC 2018/Adobe Character Animator CC 2018.app/Contents/Resources/Runtime/animal/scripts/js/lib/engine.js")
